# Tradutor Profissional - 75+ Idiomas

Aplicação web de tradução profissional com reconhecimento de voz, síntese de voz Google e suporte a mais de 75 idiomas.

## Características

- **Reconhecimento de Voz**: Fale no idioma de origem e o texto será capturado automaticamente
- **Síntese de Voz Google**: Ouça as traduções com vozes naturais do Google (masculina e feminina)
- **75+ Idiomas**: Suporte amplo para tradução entre diversos idiomas
- **Interface Responsiva**: Funciona em dispositivos móveis e desktop
- **PWA Ready**: Configurado como Progressive Web App para instalação
- **Suporte Offline**: Funcionalidades disponíveis mesmo sem conexão

## Tecnologias

- HTML5
- CSS3 (com gradientes e animações)
- JavaScript (vanilla)
- Web Speech API
- Google Text-to-Speech
- Service Workers (PWA)

## Como Usar

1. Abra o arquivo `tradutor-profissional.html` em um navegador moderno
2. Selecione o idioma de origem e destino
3. Digite ou use o botão "FALAR" para entrada por voz
4. Clique em "OUVIR" para ouvir a tradução
5. Use o botão de copiar para copiar a tradução

## Arquivo

O arquivo `tradutor-profissional.html` é uma aplicação standalone completa que contém todo o código necessário (HTML, CSS e JavaScript) em um único arquivo.

## Compatibilidade

- Chrome/Edge (recomendado)
- Firefox
- Safari
- Opera

**Nota**: Recursos de voz podem variar dependendo do navegador e sistema operacional.

# Instruções para Upload no GitHub

Este guia apresenta os passos necessários para fazer upload deste projeto no GitHub.

## Opção 1: Upload via Interface Web do GitHub

Esta é a forma mais simples e direta para quem está começando.

### Passos

1. Acesse o [GitHub](https://github.com) e faça login na sua conta
2. Clique no botão **"+"** no canto superior direito e selecione **"New repository"**
3. Preencha as informações do repositório:
   - **Repository name**: `tradutor-profissional` (ou outro nome de sua preferência)
   - **Description**: "Aplicação web de tradução profissional com reconhecimento de voz e 75+ idiomas"
   - Escolha se o repositório será **Public** ou **Private**
   - Marque a opção **"Add a README file"** (você pode substituir depois)
4. Clique em **"Create repository"**
5. Na página do repositório criado, clique em **"uploading an existing file"** ou arraste os arquivos
6. Faça upload dos seguintes arquivos:
   - `tradutor-profissional.html`
   - `README.md`
7. Adicione uma mensagem de commit (ex: "Adicionar aplicação de tradução profissional")
8. Clique em **"Commit changes"**

## Opção 2: Upload via Git CLI (Linha de Comando)

Esta opção é recomendada para quem já tem familiaridade com Git e deseja mais controle.

### Pré-requisitos

Certifique-se de ter o Git instalado no seu computador. Você pode verificar executando o comando `git --version` no terminal.

### Passos

1. Crie um novo repositório no GitHub seguindo os passos 1-4 da Opção 1, mas **não** marque a opção "Add a README file"

2. Abra o terminal e navegue até o diretório do projeto:
   ```bash
   cd caminho/para/tradutor-profissional-projeto
   ```

3. Inicialize o repositório Git local:
   ```bash
   git init
   ```

4. Adicione todos os arquivos ao staging:
   ```bash
   git add .
   ```

5. Faça o primeiro commit:
   ```bash
   git commit -m "Adicionar aplicação de tradução profissional"
   ```

6. Conecte o repositório local ao repositório remoto do GitHub (substitua `seu-usuario` pelo seu nome de usuário):
   ```bash
   git remote add origin https://github.com/seu-usuario/tradutor-profissional.git
   ```

7. Envie os arquivos para o GitHub:
   ```bash
   git branch -M main
   git push -u origin main
   ```

8. Se solicitado, faça login com suas credenciais do GitHub

## Opção 3: Upload via GitHub CLI

Para quem prefere usar a ferramenta oficial do GitHub na linha de comando.

### Pré-requisitos

Instale o [GitHub CLI](https://cli.github.com/) e faça login com `gh auth login`.

### Passos

1. Navegue até o diretório do projeto:
   ```bash
   cd caminho/para/tradutor-profissional-projeto
   ```

2. Inicialize o repositório e crie no GitHub:
   ```bash
   git init
   gh repo create tradutor-profissional --public --source=. --remote=origin
   ```

3. Adicione os arquivos e faça commit:
   ```bash
   git add .
   git commit -m "Adicionar aplicação de tradução profissional"
   ```

4. Envie para o GitHub:
   ```bash
   git push -u origin main
   ```

## Habilitando GitHub Pages (Opcional)

Para hospedar a aplicação gratuitamente no GitHub Pages e torná-la acessível via URL pública, siga estes passos:

1. No repositório do GitHub, clique em **"Settings"**
2. No menu lateral, clique em **"Pages"**
3. Em **"Source"**, selecione a branch **"main"** e a pasta **"/ (root)"**
4. Clique em **"Save"**
5. Aguarde alguns minutos e sua aplicação estará disponível em: `https://seu-usuario.github.io/tradutor-profissional/tradutor-profissional.html`

## Estrutura do Projeto

Após o upload, seu repositório terá a seguinte estrutura:

```
tradutor-profissional/
├── README.md
├── tradutor-profissional.html
└── INSTRUCOES-GITHUB.md (opcional)
```

## Dicas Adicionais

- Mantenha o arquivo `README.md` atualizado com informações sobre o projeto
- Considere adicionar um arquivo `.gitignore` se houver arquivos que não devem ser versionados
- Use commits descritivos para facilitar o acompanhamento das mudanças
- Se fizer alterações no projeto, use `git add`, `git commit` e `git push` para atualizar o repositório

## Recursos Úteis

- [Documentação oficial do Git](https://git-scm.com/doc)
- [Guias do GitHub](https://guides.github.com/)
- [GitHub Pages](https://pages.github.com/)
